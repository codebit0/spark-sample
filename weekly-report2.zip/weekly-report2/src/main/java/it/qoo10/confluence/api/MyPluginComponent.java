package it.qoo10.confluence.api;

public interface MyPluginComponent
{
    String getName();
}
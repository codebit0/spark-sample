package ut.it.qoo10.confluence;

import org.junit.Test;
import it.qoo10.confluence.api.MyPluginComponent;
import it.qoo10.confluence.impl.MyPluginComponentImpl;

import static org.junit.Assert.assertEquals;

public class MyComponentUnitTest
{
    @Test
    public void testMyName()
    {
        MyPluginComponent component = new MyPluginComponentImpl(null);
        assertEquals("names do not match!", "myComponent",component.getName());
    }
}